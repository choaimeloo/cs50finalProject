document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('submit').onclick = function() {
    	alert("Write on! Post submitted!");
	};
});
